<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 
                            
    <section class="bg-cover" style="background-image: url(<?php echo e(asset('img/cursos/portada.jpg')); ?>) ">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-36">
            <div class="w-full md:w-3/4 lg:w-1/2">
                <h1 class="text-white font-fold text-4xl">Los mejores cursos de programación ¡GRATIS! y en español.  </h1> 
                <p class="text-white text-lg mt-2">Si estás buscando potenciar tus conocimientos de programación, has llegado al lugar adecuado. Encuentra cursos y proyectos que te ayudarán en ese proceso</p>
                                  
                           <!-- COMPONENTE BUSCADOR  con livewire search.blad.php -->
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('xyoxkZI')) {
    $componentId = $_instance->getRenderedChildComponentId('xyoxkZI');
    $componentTag = $_instance->getRenderedChildComponentTagName('xyoxkZI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xyoxkZI');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('xyoxkZI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                  
            </div>
        </div>
    </section>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('courses-index')->html();
} elseif ($_instance->childHasBeenRendered('bT6VxrW')) {
    $componentId = $_instance->getRenderedChildComponentId('bT6VxrW');
    $componentTag = $_instance->getRenderedChildComponentTagName('bT6VxrW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bT6VxrW');
} else {
    $response = \Livewire\Livewire::mount('courses-index');
    $html = $response->html();
    $_instance->logRenderedChild('bT6VxrW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mfcz\resources\views/courses/index.blade.php ENDPATH**/ ?>