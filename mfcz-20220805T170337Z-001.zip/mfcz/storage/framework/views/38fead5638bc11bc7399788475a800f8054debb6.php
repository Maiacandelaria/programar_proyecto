<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            
    <section class="bg-cover" style="background-image: url(<?php echo e(asset('img/home/imagenhome.jpg')); ?>) ">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-36">
            <div class="w-full md:w-3/4 lg:w-1/2">
                <h1 class="text-white font-fold text-4xl">Domina la tecnología web con Coders Free  </h1> 
                <p class="text-white text-lg mt-2">En Coders Free encontrarás cursos, manuales y artículos que te ayudarán a convertirte en un profesional del desarrollador web</p>
          
                       <!-- COMPONENTE BUSCADOR  -->
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('vwur2fc')) {
    $componentId = $_instance->getRenderedChildComponentId('vwur2fc');
    $componentTag = $_instance->getRenderedChildComponentTagName('vwur2fc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vwur2fc');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('vwur2fc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          
            </div>
        </div>
    </section>

    <section class="mt-16">
        <h1 class="text-gray-600 text-center text-3xl mb-6">CONTENIDO</h1>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3  lg:grid-cols-4 gap-x-6 gap-y-8">
            <article>
                <figure>
                    <img class="rounded-xl h-36 w-full object-cover" src="<?php echo e(asset('img/home/home-office-336377_1280.jpg')); ?>" alt="">
                </figure>

                <header class="mt-2">
                    <h1 class="text-center text-xl text-gray-500">Cursos y proyectos</h1>
                </header>
                    <p class="text-sm text-gray-500 ">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </article>

            <article>
                <figure>
                    <img class="rounded-xl h-36 w-full object-cover" src="<?php echo e(asset('img/home/laptop-336378_1280.jpg')); ?>" alt="">
                </figure>
                <header class="mt-2">
                    <h1 class="text-center text-xl text-gray-500">Manual de Laravel</h1>
                </header>
                    <p class="text-sm text-gray-500 ">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </article>

            <article>
                <figure>
                    <img class="rounded-xl h-36 w-full object-cover" src="<?php echo e(asset('img/home/laptop-3087585_1280.jpg')); ?>" alt="">
                </figure>
                <header class="mt-2">
                    <h1 class="text-center text-xl text-gray-500">Blog</h1>
                </header>
                    <p class="text-sm text-gray-500 ">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </article>

            <article>
                <figure>
                    <img class="rounded-xl h-36 w-full object-cover" src="<?php echo e(asset('img/home/laptop-5842509_1280.jpg')); ?>" alt="">
                </figure>
                <header class="mt-2">
                    <h1 class="text-center text-xl text-gray-500">Desarrollo web</h1>
                </header>
                    <p class="text-sm text-gray-500 ">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </article>
        </div>
    </section>

    <section class="mt-16 bg-blue-900 py-12">
        <h1 class="text-yellow-300 text-center text-3xl ">¿No sabes qué curso llevar?</h1>
        <p class="text-yellow-300 text-center text-lg">Dirígete al catálogo de cursos y filtralos por categoría o nivel</p>
            <div class="flex justify-center mt-4">
                    <a href="<?php echo e(route('courses.index')); ?>" class="bg-red-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Catálogo de cursos
                    </a>
            </div>
    </section>

    <section class="my-24">
            <div>
                <h1 class="text-gray-700 text-center text-3xl">ÚLTIMOS CURSOS</h1>
                <p class="text-gray-700 text-center text-md mb-6">Trabajo duro para seguir subiendo cursos</p>
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid sm:grid-cols-2 md:grid-cols-3  lg:grid-cols-4 gap-x-6 gap-y-8">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.course-card','data' => ['course' => $course]]); ?>
<?php $component->withName('course-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['course' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
    </section>
    
    
    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/welcome.blade.php ENDPATH**/ ?>