<div class="container py-8">
   <!-- This example requires Tailwind CSS v2.0+ -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table-responsive','data' => []]); ?>
<?php $component->withName('table-responsive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="px-6 py-4 flex">
                    <input wire:keydown="limpiar_page" wire:model="search" class="form-input flex-1 shadow-sm" placeholder="Ingrese el nombre de un curso...">
                    <a class="btn btn-danger ml-2" href="<?php echo e(route('instructor.courses.create')); ?>">Crear nuevo curso</a>
                </div>

                <?php if($courses->count()): ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        NOMBRE
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        MATRICULADOS
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        CALIFICACIÓN
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        STATUS
                        </th>
                        <th scope="col" class="relative px-6 py-3">
                        <span class="sr-only">Edit</span>
                        </th>
                    </tr>
                    </thead>
                  
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <?php if(isset($course->image)): ?>
                                           <img class="h-10 w-10 rounded-full object-cover object-center" src="<?php echo e(Storage::url($course->image->url)); ?>">
                                        <?php else: ?> 
                                          <img class="h-10 w-10 rounded-full object-cover object-center" src="https://images.pexels.com/photos/5905885/pexels-photo-5905885.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260">
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?php echo e($course->title); ?>

                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo e($course->category->name); ?>

                                    </div>
                                    </div>
                                </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"><?php echo e($course->students->count()); ?></div>
                                    <div class="text-sm text-gray-500">Alumnos Matriculados</div>
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900 flex items-center">
                                        <?php echo e($course->rating); ?>

                                        <ul class="flex text-sm ml-2">
                                            <li class="mr-1">
                                                <i class="fas fa-star text-<?php echo e($course->rating >= 1 ? 'yellow' : 'gray'); ?>-400"></i>
                                            </li>
                                            <li class="mr-1">
                                                <i class="fas fa-star text-<?php echo e($course->rating >= 2 ? 'yellow' : 'gray'); ?>-400"></i>
                                            </li>
                                            <li class="mr-1">
                                                <i class="fas fa-star text-<?php echo e($course->rating >= 3 ? 'yellow' : 'gray'); ?>-400"></i>
                                            </li>
                                            <li class="mr-1">
                                                <i class="fas fa-star text-<?php echo e($course->rating >= 4 ? 'yellow' : 'gray'); ?>-400"></i>
                                            </li>
                                            <li class="mr-1">
                                                <i class="fas fa-star text-<?php echo e($course->rating == 5 ? 'yellow' : 'gray'); ?>-400"></i>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="text-sm text-gray-500">Valoración del Curso</div>
                                </td>
                  

                                <td class="px-6 py-4 whitespace-nowrap">

                                    <?php switch($course->status):
                                        case (1): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                Borrador
                                            </span>                                           
                                        <?php break; ?>

                                        <?php case (2): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                Revisión
                                            </span>                                           
                                        <?php break; ?>
                                        
                                        <?php case (3): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Publicado
                                            </span>                                            
                                        <?php break; ?>

                                        <?php default: ?>
                                            
                                    <?php endswitch; ?>

                                   
                                </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <a href="<?php echo e(route('instructor.courses.edit', $course)); ?>" class="text-indigo-600 hover:text-indigo-900">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- More items... -->
                    </tbody>
                </table>

                <div class="px-6 py-4">
                    <?php echo e($courses->links()); ?>

                </div>
                <?php else: ?>
                    <div class="px-6 py-4">
                        No se encontró ningun registro ...
                    </div>
                <?php endif; ?>    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/livewire/instructor/courses-index.blade.php ENDPATH**/ ?>