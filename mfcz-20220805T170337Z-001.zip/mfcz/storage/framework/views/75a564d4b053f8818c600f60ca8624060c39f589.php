<div>
   <h1 class="text-2xl font-bold mb-4">ESTUDIANTES DEL CURSO</h1>

   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table-responsive','data' => []]); ?>
<?php $component->withName('table-responsive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="px-6 py-4 ">
        <input wire:model="search" class="form-input flex-1 w-full shadow-sm" placeholder="Ingrese el nombre de un curso...">
    </div>

    <?php if($students->count()): ?>
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
        <tr>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
            NOMBRE
            </th>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
            E-mail
            </th>
           
            <th scope="col" class="relative px-6 py-3">
            <span class="sr-only">Edit</span>
            </th>
        </tr>
        </thead>
      
        <tbody class="bg-white divide-y divide-gray-200">
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <div class="flex-shrink-0 h-10 w-10">
                            
                              <img class="h-10 w-10 rounded-full object-cover object-center" src="<?php echo e($student->profile_photo_url); ?>">
                           
                        </div>
                            <div class="ml-4">
                                <div class="text-sm font-medium text-gray-900">
                                    <?php echo e($student->name); ?>

                                </div>
                               
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($student->email); ?></div>
                    </td>

                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <a href="" class="text-indigo-600 hover:text-indigo-900">Ver</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- More items... -->
        </tbody>
    </table>

    <div class="px-6 py-4">
        <?php echo e($students->links()); ?>

    </div>
    <?php else: ?>
        <div class="px-6 py-4">
            No se encontró ningun registro ...
        </div>
    <?php endif; ?>    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/livewire/instructor/courses-students.blade.php ENDPATH**/ ?>