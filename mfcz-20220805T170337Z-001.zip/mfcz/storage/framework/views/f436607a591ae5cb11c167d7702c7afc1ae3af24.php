<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <section class="bg-gray-700 py-12 mb-12">
        <div class="container grid grid-cols-1 lg:grid-cols-2 gap-6">

            <figure>
                <img class="h-60 w-full object-cover" src="<?php echo e($course->image->url); ?> " alt="">
            </figure>

            <div class="text-white ">
                <h1 class="text-3xl"><?php echo e(Str::limit($course->title, 40)); ?></h1>
                <h2 class="text-xl mb-6"><?php echo e($course->subtitle); ?></h2>

                <p class="mb-3"><i class="fas fa-chart-line mr-2"></i>Nivel: <?php echo e($course->level->name); ?></p>
                <p class="mb-3"><i class="fas fa-layer-group mr-2"></i>Categoria: <?php echo e($course->category->name); ?></p>
                <p class="mb-3"><i class="fas fa-user mr-2"></i>Matriculados: <?php echo e($course->students_count); ?></p>
                <p><i class="far fa-star"></i> Calificación: <?php echo e($course->rating); ?></p>
            </div>
        </div>
    </section>

    <div class="container grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="order-2 lg:col-span-2 lg:order-1">
            <section class="card mb-12">
                <div class="card-body">
                    <h1 class="font-bold text-2xl mb-2">Lo que aprenderás</h1>

                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                        <?php $__currentLoopData = $course->goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-gray-700 text-base"><i class="fas fa-check text-gray-600 mr-2"></i> <?php echo e($goal->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </section>

            <section class="mb-12">
               <h1 class="font-fold text-3xl mb-2">Temario</h1>
               <?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <article class="mb-4 shadow"
                           <?php if($loop->first): ?>
                               x-data="{open: true}"
                           <?php else: ?>
                               x-data="{open: false}"
                           <?php endif; ?>
                           >
                        <header class="border border-gray-200 px-4 py-2 cursor-pointer bg-gray-200" x-on:click="open = !open">
                            <h1 class="font-bold text-lg text-gray-600"><?php echo e($section->name); ?></h1>
                        </header>
                        <div class="bg-white py-2 px-4" x-show="open">
                            <ul class="grid grid-cols-1 gap-2">
                                <?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-gray-700 text-base"><i class="fas fa-play-circle mr-2 text-gray-600"></i> <?php echo e($lesson->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                   </article>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="mb-8 text-gray-800 ">
                <h1 class="font-bold text-3xl">Requisitos</h1>
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $course->requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-gray-700 text-base"><?php echo e($requirement->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>

            <section>
                <h1 class="font-bold text-3xl text-gray-800 ">Descripción</h1>
                <div class="text-gray-700 text-base">
                    <?php echo $course->description; ?>

                </div>
             </section>

             <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('courses-reviews', ['course' => $course])->html();
} elseif ($_instance->childHasBeenRendered('rwzJIgX')) {
    $componentId = $_instance->getRenderedChildComponentId('rwzJIgX');
    $componentTag = $_instance->getRenderedChildComponentTagName('rwzJIgX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rwzJIgX');
} else {
    $response = \Livewire\Livewire::mount('courses-reviews', ['course' => $course]);
    $html = $response->html();
    $_instance->logRenderedChild('rwzJIgX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <div class="order-1 lg:order-2">
        <section class="card mb-4">
                <div class="card-body">
                    <div class="flex items-center">
                        <img class="h-12 w-12 object-cover shadow-lg rounded-full"  src="<?php echo e($course->teacher->profile_photo_url); ?>" alt="<?php echo e($course->teacher->name); ?>">
                        <div class="ml-4">
                           <h1 class="font-fold text-gray-500 text-lg">Prof: <?php echo e($course->teacher->name); ?></h1>
                           <a class="text-blue-500 text-sm font-bold" href=""><?php echo e('@' . Str::slug($course->teacher->name, '' )); ?></a>
                        </div>
                    </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enrolled', $course)): ?>
                            <a class="btn btn-danger btn-block mt-4" href="<?php echo e(route('courses.status', $course)); ?>">Continuar con el curso</a>
                        <?php else: ?>
                            <form action="<?php echo e(route('courses.enrolled', $course)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-block mt-4" type="submit">
                                    Llevar este curso
                                </button>
                            </form>
                        <?php endif; ?>
                </div>
        </section>
        <aside class="hidden lg:block">
            <?php $__currentLoopData = $similares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="flex mb-6">
                    <img class="h-32 w-40 object-cover" src="<?php echo e($similar->image->url); ?>" alt="">
                    <div class="">
                        <h1 class="ml-3">
                            <a class="font-bold text-gray-500 mb-3" href="<?php echo e(route('courses.show', $similar)); ?>"><?php echo e(Str::limit($similar->title, 40)); ?></a>
                        </h1>
                        <div class="flex items-center mb-2">
                            <img class="w-8 h-8 rounded-full object-cover shadow-lg ml-2" src="<?php echo e($similar->teacher->profile_photo_url); ?>" alt="">
                            <p class="text-gray-500 text-sm ml-2"><?php echo e($similar->teacher->name); ?></p>
                        </div>
                            <p class="ml-2 text-sm"><i class="fas fa-star mr-2 text-yellow-300"></i><?php echo e($similar->rating); ?></p>
                    </div>

                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </aside>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/courses/show.blade.php ENDPATH**/ ?>