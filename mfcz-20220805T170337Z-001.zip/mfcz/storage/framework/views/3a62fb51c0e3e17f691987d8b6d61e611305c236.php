<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <section class="bg-gray-700 py-12 mb-12">
        <div class="container grid grid-cols-1 lg:grid-cols-2 gap-6">

            <figure>
               <?php if($course->image): ?>
                    <img class="h-60 w-full object-cover" src="<?php echo e(Storage::url($course->image->url)); ?>" alt="">
               <?php else: ?>
                    <img class="h-60 w-full object-cover" src="https://images.pexels.com/photos/5905885/pexels-photo-5905885.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260" alt="">
               <?php endif; ?>
            </figure>

            <div class="text-white ">
                <h1 class="text-3xl"><?php echo e(Str::limit($course->title, 40)); ?></h1>
                <h2 class="text-xl mb-6"><?php echo e($course->subtitle); ?></h2>

                <p class="mb-3"><i class="fas fa-chart-line mr-2"></i>Nivel: <?php echo e($course->level->name); ?></p>
                <p class="mb-3"><i class="fas fa-layer-group mr-2"></i>Categoria: <?php echo e($course->category->name); ?></p>
                <p class="mb-3"><i class="fas fa-user mr-2"></i>Matriculados: <?php echo e($course->students_count); ?></p>
                <p><i class="far fa-star"></i> Calificación: <?php echo e($course->rating); ?></p>
            </div>
        </div>
    </section>

    <div class="container grid grid-cols-1 lg:grid-cols-3 gap-6">
        <?php if(session('info')): ?>
            <div class="lg:col-span-3" x-data="{open: true}" x-show="open">
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <strong class="font-bold">Ocurrió un error!</strong>
                    <span class="block sm:inline"><?php echo e(session('info')); ?></span>
                    <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                      <svg x-on:click="open= false" class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                    </span>
                  </div>
            </div>
        <?php else: ?>

        <?php endif; ?>

        <div class="order-2 lg:col-span-2 lg:order-1">
            
            <section class="card mb-12">
                <div class="card-body">
                    <h1 class="font-bold text-2xl mb-2">Lo que aprenderás</h1>

                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">

                        <?php $__empty_1 = true; $__currentLoopData = $course->goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="text-gray-700 text-base"><i class="fas fa-play-circle mr-2 text-gray-600"></i> <?php echo e($goal->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="text-gray-700 text-base">Este curso no tiene asignado ninguna meta</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </section>

            

            <section class="mb-12">
               <h1 class="font-fold text-3xl mb-2">Temario</h1>
               <?php $__empty_1 = true; $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <article class="mb-4 shadow"
                           <?php if($loop->first): ?>
                               x-data="{open: true}"
                           <?php else: ?>
                               x-data="{open: false}"
                           <?php endif; ?>
                           >
                        <header class="border border-gray-200 px-4 py-2 cursor-pointer bg-gray-200" x-on:click="open = !open">
                            <h1 class="font-bold text-lg text-gray-600"><?php echo e($section->name); ?></h1>
                        </header>
                        <div class="bg-white py-2 px-4" x-show="open">
                            <ul class="grid grid-cols-1 gap-2">
                                <?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-gray-700 text-base"><i class="fas fa-play-circle mr-2 text-gray-600"></i> <?php echo e($lesson->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                   </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <article class="card">
                        <div class="card-body">
                            Este curso no tiene ninguna sección asignada
                        </div>
                   </article>

               <?php endif; ?>
            </section>

            
            <section class="mb-8">
                <h1 class="font-bold text-3xl">Requisitos</h1>
                <ul class="list-disc list-inside">
                    <?php $__empty_1 = true; $__currentLoopData = $course->requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="text-gray-700 text-base"><?php echo e($requirement->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-gray-700 text-base">Este curso no tiene ningún requerimiento</li>
                    <?php endif; ?>
                </ul>
            </section>

            <section>
                <h1 class="font-bold text-3xl ">Descripción</h1>
                <div class="text-gray-700 text-base">
                    <?php echo $course->description; ?>

                </div>
             </section>
        </div>

        <div class="order-1 lg:order-2">
            <section class="card mb-4">
                    <div class="card-body">
                        <div class="flex items-center">
                            <img class="h-12 w-12 object-cover shadow-lg rounded-full"  src="<?php echo e($course->teacher->profile_photo_url); ?>" alt="<?php echo e($course->teacher->name); ?>">
                            <div class="ml-4">
                            <h1 class="font-fold text-gray-500 text-lg">Prof: <?php echo e($course->teacher->name); ?></h1>
                            <a class="text-blue-500 text-sm font-bold" href=""><?php echo e('@' . Str::slug($course->teacher->name, '' )); ?></a>
                            </div>
                        </div>
                        <form action="<?php echo e(route('admin.courses.approved', $course)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-primary w-full mt-4">Aprobar curso</button>
                        </form>
                            <a href="<?php echo e(route('admin.courses.observation', $course)); ?>" class="btn btn-danger w-full block text-center mt-4">Observar curso</a>

                    </div>
            </section>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/admin/courses/show.blade.php ENDPATH**/ ?>