<div>
    

    <h1 class="text-2xl font-bold">LECCIONES DEL CURSO</h1>
    <hr class="mt-2 mb-6 ">
     
       <?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <article class="card mb-6" x-data="{open: true}">
                <div class="card-body bg-gray-200">

                    <?php if($section->id == $item->id): ?>

                        <form wire:submit.prevent="update">
                            <input wire:model="section.name" class="form-input w-full" placeholder="Ingrese el nombre de la sección...">
                        
                            <?php $__errorArgs = ['section.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                        </form>
                    <?php else: ?>
                        <header class="flex justify-between items-center">
                            <h1 x-on:click="open = !open" class="cursor-pointer"><strong>Sección:</strong><?php echo e($item->name); ?> </h1>   
                                <div>
                                    <i class="fas fa-edit cursor-pointer text-blue-500" wire:click="edit(<?php echo e($item); ?>)"></i>
                                    <i class="fas fa-eraser cursor-pointer text-red-500" wire:click="destroy(<?php echo e($item); ?>)"></i>
                                </div>                      
                        </header>

                        <div x-show="open">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.courses-lesson', ['section' => $item])->html();
} elseif ($_instance->childHasBeenRendered($item->id)) {
    $componentId = $_instance->getRenderedChildComponentId($item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.courses-lesson', ['section' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild($item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    <?php endif; ?>
               </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       
       <div x-data="{open: false}">
           <a x-show="!open" x-on:click="open = true" class="flex items-center cursor-pointer">
                <i class="far fa-plus-square text-2xl text-red-500 mr-2"></i>
                    Agregar nueva sección
           </a>
           <article class="card" x-show="open">
               <div class="card-body bg-gray-100">
                    <h1 class="text-xl font-bold mb-4 cursor-pointer">Agregar nueva sección</h1>
                  
                    <div class="mb-4"> 
                        <input wire:model="name"  class="form-input w-full" placeholder="Escriba el nombre de la lección ...">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  
                    <div class="flex justify-end ">
                        <button class="btn btn-danger" x-on:click="open = false">Cancelar</button>
                        <button class="btn btn-primary ml-2" wire:click="store">Agregar</button>
                    </div>
               </div>
           </article>
       </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/livewire/instructor/courses-curriculum.blade.php ENDPATH**/ ?>