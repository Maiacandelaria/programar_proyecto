<div class="mt-8">
    <div class="container grid grid-cols-1 lg:grid-cols-3  gap-x-8">
        <div class="lg:col-span-2">
            <div class="embed-responsive">
                <?php echo $current->iframe; ?>

            </div>

            <h1 class="text-3xl text-gray-600 font-bold mt-4">
                <?php echo e($current->name); ?>

            </h1>
            <?php if($current->description): ?>
                <div class="text-gray-600">
                    <?php echo e($current->description->name); ?>

                </div>
            <?php endif; ?>

            <div class="flex items-center mt-4 cursor-pointer" wire:click="completed">
                <?php if($current->completed): ?>
                   <i class="fas fa-toggle-on text-2xl text-blue-600 "></i>
                <?php else: ?>
                    <i class="fas fa-toggle-off text-2xl text-gray-600 "></i>
                <?php endif; ?>

                <p class="text-sm ml-2">Marcar esta unidad como terminada</p>
            </div>

            <div class="card mt-2">
                <div class="card-body flex text-gray-500 font-bold">
                    
                    <?php if($this->previous): ?>
                       <a wire:click="changeLesson(<?php echo e($this->previous); ?>)" class="cursor-pointer"> Tema anterior</a>
                    <?php endif; ?>

                    <?php if($this->next): ?>
                       <a wire:click="changeLesson(<?php echo e($this->next); ?>)" class="ml-auto cursor-pointer">Siguiente tema</a>
                    <?php endif; ?>
                  
                </div>
            </div>

        </div>
        
        <div class="card">
            <div class="card-body">
                <h1 class="text-2xl leading-8 text-center mb-4"><?php echo e($course->title); ?></h1>
                <div class="flex items-center">
                    <figure>
                        <img class="w-12 h-12 object-cover rounded-full mr-4" src="<?php echo e($course->teacher->profile_photo_url); ?>" alt="">
                    </figure>
                    <div>
                        <p><?php echo e($course->teacher->name); ?></p>
                        <a class="text-blue-500 text-sm" href=""><?php echo e('@' . Str::slug($course->teacher->name, '')); ?></a>
                    </div>
                 </div>

                 <p class="text-gray-600 text-sm mt-2 "><?php echo e($this->advance . '% '); ?>Completado</p>
                 <div class="relative pt-1">
                    <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-yellow-100">
                      <div style="width:<?php echo e($this->advance . '% '); ?>" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500 transition-all duration-200"></div>
                    </div>
                  </div>

                 <ul>
                     <?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li class="text-gray-600 mb-4">
                             <a class="font-bold text-base inline-block mb-2"><?php echo e($section->name); ?></a>
                             <ul>
                                 <?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex mb-1">
                                        <div>
                                            <?php if($lesson->completed): ?>
                                               <?php if($current->id == $lesson->id): ?>
                                                 <span class="inline-block w-4 h-4 border-2 border-yellow-300 rounded-full mr-2 mt-1"></span>   
                                               <?php else: ?>
                                                 <span class="inline-block w-4 h-4 bg-yellow-300 rounded-full mr-2 mt-1"></span>   
                                               <?php endif; ?>
                                            <?php else: ?> 
                                                <?php if($current->id == $lesson->id): ?>
                                                <span class="inline-block w-4 h-4 border-2 border-gray-500 rounded-full mr-2 mt-1"></span>   
                                                <?php else: ?> 
                                                <span class="inline-block w-4 h-4 bg-gray-500 rounded-full mr-2 mt-1"></span> 
                                                <?php endif; ?>
                                               
                                            <?php endif; ?>
                                        </div>
                                        <a class="cursor-pointer" wire:click="changeLesson(<?php echo e($lesson); ?>)"><?php echo e($lesson->name); ?></a>
                                    </li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </ul>
                         </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul>


            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/livewire/course-status.blade.php ENDPATH**/ ?>