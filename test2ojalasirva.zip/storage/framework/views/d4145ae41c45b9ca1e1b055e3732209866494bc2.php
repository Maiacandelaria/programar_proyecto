<?php $attributes = $attributes->exceptProps(['course']); ?>
<?php foreach (array_filter((['course']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<article class="card flex flex-col">

    <img class="card flex flex-col">
        <?php if(isset($course->image)): ?>
             <img id="picture" class="h-36 w-full object-cover" src="<?php echo e(($course->image->url)); ?>" alt="">
        <?php else: ?>
             <img id="picture" class="h-36 w-full object-cover" src="https://images.pexels.com/photos/5905885/pexels-photo-5905885.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260" alt="">
        <?php endif; ?>
</img>
        
    <div class="card-body flex-1 flex flex-col">
            <h1 class="card-title"><?php echo e(Str::limit($course->title, 40)); ?>  </h1>
            <p class="text-gray-700 text-center text-sm mb-2 mt-auto">Prof:<?php echo e($course->teacher->name); ?></p>

                <div class="flex">
                    <ul class="flex text-sm ">
                        <li class="mr-2">
                            <i class="fas fa-star text-<?php echo e($course->rating >= 1 ? 'yellow' : 'gray'); ?>-400"></i>
                        </li>
                        <li class="mr-2">
                            <i class="fas fa-star text-<?php echo e($course->rating >= 2 ? 'yellow' : 'gray'); ?>-400"></i>
                        </li>
                        <li class="mr-2">
                            <i class="fas fa-star text-<?php echo e($course->rating >= 3 ? 'yellow' : 'gray'); ?>-400"></i>
                        </li>
                        <li class="mr-1">
                            <i class="fas fa-star text-<?php echo e($course->rating >= 4 ? 'yellow' : 'gray'); ?>-400"></i>
                        </li>
                        <li class="mr-1">
                            <i class="fas fa-star text-<?php echo e($course->rating == 5 ? 'yellow' : 'gray'); ?>-400"></i>
                        </li>
                    </ul>

                        <p class="text-sm text-gray-500 ml-auto">
                            <i class="fas fa-users"></i>
                            (<?php echo e($course->students_count); ?>)
                        </p>
                </div>

                <a href="<?php echo e(route('courses.show', $course)); ?>" class=" mt-4  bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500  focus:ring-4 focus:outline-none focus:ring-green-200 dark:focus:ring-green-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 btn-block transform transition duration-700 hover:scale-110 hover:text-white text-sm px-5 py-2.5 text-center  mr-2 mb-2">
                    Más información
                </a>
        </div>
</article>
<?php /**PATH C:\xampp\htdocs\programar_proyecto\resources\views/components/course-card.blade.php ENDPATH**/ ?>