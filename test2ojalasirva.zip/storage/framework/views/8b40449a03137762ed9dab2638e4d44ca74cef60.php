<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\programar_proyecto\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>