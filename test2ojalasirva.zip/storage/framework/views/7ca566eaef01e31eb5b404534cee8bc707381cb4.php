<section class="mt-4">
    <h1 class="font-bold text-3xl text-gray-800 mb-2">Valoración</h1>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enrolled', $course)): ?>
        <article>
            <textarea wire:model="comment" class="form-input w-full" rows="3" placeholder="Ingrese una reseña del curso"></textarea>

                <div class="flex items-center">
                    <button class="btn btn-primary mr-2" wire:click="store">Guardar</button>

                        <ul class="flex ">
                            <li class="mr-1 cursor-pointer" wire:click="set('rating', 1)">
                                <i class="fas fa-star text-<?php echo e($rating >= 1 ? 'yellow' : 'gray'); ?>-400"></i>
                            </li>
                            <li class="mr-1 cursor-pointer" wire:click="set('rating', 2)">
                                <i class="fas fa-star text-<?php echo e($rating >= 2 ? 'yellow' : 'gray'); ?>-400"></i>
                            </li>
                            <li class="mr-1 cursor-pointer" wire:click="set('rating', 3)">
                                <i class="fas fa-star text-<?php echo e($rating >= 3 ? 'yellow' : 'gray'); ?>-400"></i>
                            </li>
                            <li class="mr-1 cursor-pointer" wire:click="set('rating', 4)">
                                <i class="fas fa-star text-<?php echo e($rating >= 4 ? 'yellow' : 'gray'); ?>-400"></i>
                            </li>
                            <li class="mr-1 cursor-pointer" wire:click="set('rating', 5)">
                                <i class="fas fa-star text-<?php echo e($rating == 5 ? 'yellow' : 'gray'); ?>-400"></i>
                            </li>
                        </ul>

                </div>
        </article>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <p class="text-gray-800 text-xl"><?php echo e($course->reviews->count()); ?> Valoraciones</p>
            <?php $__currentLoopData = $course->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="flex mb-4 text-gray-800">
                    <figure class="mr-4">
                        <img class="h-12 w-12 object-cover rounded-full shadow-xs" src="<?php echo e($review->user->profile_photo_url); ?>" alt="">
                    </figure>
                    
                    <div class="card flex-1">
                        <div class="card-body bg-gray-100">
                            <p><b><?php echo e($review->user->name); ?></b><i class="fas fa-star text-yellow-300"></i>(<?php echo e($review->rating); ?>)</p>

                            <?php echo e($review->comment); ?>

                        </div>
                    </div>

                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\mfcz\resources\views/livewire/courses-reviews.blade.php ENDPATH**/ ?>